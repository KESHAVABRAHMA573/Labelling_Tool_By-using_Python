from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QRadioButton, QLabel, QPushButton, QFileDialog,
    QSlider, QSizePolicy, QFrame
)
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QMenuBar, QMenu
import sys
import csv
import os
from PySide6.QtWebEngineWidgets import QWebEngineView
import plotly.graph_objects as go
from PySide6.QtWidgets import QMessageBox
from datetime import datetime
from PySide6.QtWidgets import QComboBox

class CSVSelector(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Threshold Tuner")
        self.init_ui()
        self.showMaximized()
        self.file_mode = "csv"
        self.csv_files = []


    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(10)
        menu_bar = QMenuBar(self)
        file_menu = QMenu("File", self)

        open_csv_action = file_menu.addAction("CSV")
        open_csv_action.triggered.connect(lambda: self.browse_file(mode="csv"))

        open_list_action = file_menu.addAction("List of CSV")
        open_list_action.triggered.connect(lambda: self.browse_file(mode="list"))

        menu_bar.addMenu(file_menu)
        main_layout.setMenuBar(menu_bar)
        
        help_menu = QMenu("Help", self)
        about_action = help_menu.addAction("About")
        about_action.triggered.connect(self.show_about_dialog)
        menu_bar.addMenu(help_menu)
        main_layout.setMenuBar(menu_bar)

        browse_row = QHBoxLayout()
        self.path_label = QLabel("No file selected")
        self.path_label.setStyleSheet("border: 1px solid gray; padding: 4px;")
        self.path_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

        browse_row.addWidget(self.path_label)
        browse_row.addSpacing(10)
        
        self.graph_placeholder = QFrame()
        self.graph_placeholder.setFrameStyle(QFrame.Box)
        self.graph_placeholder.setStyleSheet("background-color: #f0f0f0;")
        self.graph_placeholder.setMinimumHeight(300)

        graph_layout = QVBoxLayout(self.graph_placeholder)
        self.graph_view = QWebEngineView()
        graph_layout.addWidget(self.graph_view)

        slider_row = QHBoxLayout()
        self.header_dropdown = QComboBox()
        self.header_dropdown.setFixedWidth(200)
        self.header_dropdown.currentIndexChanged.connect(self.update_graph)
        slider_row.addWidget(self.header_dropdown)
        slider_row.addStretch()

        dec_button = QPushButton("◀")
        dec_button.setFixedWidth(30)
        dec_button.clicked.connect(self.decrement_slider)
        slider_row.addWidget(dec_button)

        self.slider = QSlider(Qt.Horizontal)
        self.slider.setMinimum(0)
        self.slider.setMaximum(100)
        self.slider.setSingleStep(1)
        self.slider.setPageStep(10)
        self.slider.setValue(0)
        self.slider.setFixedWidth(400)
        self.slider.valueChanged.connect(self.update_slider_label)
        slider_row.addWidget(self.slider)

       
        inc_button = QPushButton("▶")
        inc_button.setFixedWidth(30)
        inc_button.clicked.connect(self.increment_slider)
        slider_row.addWidget(inc_button)

        self.slider_label = QLabel("0.00")
        self.slider_label.setFixedWidth(60)
        slider_row.addSpacing(10)
        slider_row.addWidget(self.slider_label)
        slider_row.addStretch()
        
        button_row = QHBoxLayout()
        button_row.addStretch()
        generate_button = QPushButton("Generate Report")
        generate_button.clicked.connect(self.generate_report)
        button_row.addWidget(generate_button)
        button_row.addStretch()

        
        main_layout.addLayout(browse_row)
        main_layout.addSpacing(50)
        main_layout.addWidget(self.graph_placeholder, stretch=1)
        main_layout.addSpacing(10)
        slider_and_button = QVBoxLayout()
        slider_and_button.setSpacing(6) 

        slider_and_button.addLayout(slider_row)
        slider_and_button.addLayout(button_row)

        main_layout.addLayout(slider_and_button)

        self.setLayout(main_layout)
        

    
    def browse_file(self, mode="csv"):
        self.file_mode = mode  # store the mode for later use

        if mode == "csv":
            file_path, _ = QFileDialog.getOpenFileName(self, "Select CSV File", "", "CSV Files (*.csv)")
            if file_path:
                self.path_label.setText(file_path)
                self.csv_files = [file_path]
                self.load_csv_headers(file_path)
        else:
            file_path, _ = QFileDialog.getOpenFileName(self, "Select List File", "", "Text Files (*.txt)")
            if file_path:
                self.path_label.setText(file_path)
                self.csv_files = []
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        for line in f:
                            path = line.strip().strip('"')
                            if path.endswith(".csv") and os.path.isfile(path):
                                self.csv_files.append(path)
                except Exception as e:
                    print(f"Error reading list file: {e}")
                    self.csv_files = []

                self.load_common_headers(self.csv_files)
        self.update_graph()

    def load_common_headers(self, csv_files):
        header_sets = []
        for path in csv_files:
            try:
                with open(path, newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    headers = next(reader, [])
                    cleaned = [h.strip().lstrip('\ufeff') for h in headers]
                    header_sets.append(set(cleaned))
            except Exception as e:
                print(f"Error reading headers from {path}: {e}")

        if header_sets:
            common = set.intersection(*header_sets)
            self.header_dropdown.clear()
            self.header_dropdown.addItems(sorted(common))
        else:
            self.header_dropdown.clear()

    def update_slider_label(self, value):
        float_value = value / 100.0
        self.slider_label.setText(f"{float_value:.2f}")
        self.update_graph()

    def update_graph(self):
        file_path = self.path_label.text()
        threshold = self.slider.value() / 100.0
        csv_files = self.csv_files

        if not csv_files:
            print("No valid CSV files found.")
            self.graph_view.setHtml("<h3>No valid CSV files found.</h3>")
            return

        bars = []
        for csv_path in csv_files:
            detection_count, img_count = self.compute_detection_stats(csv_path, threshold)
            percent = round((detection_count / img_count) * 100, 2) if img_count > 0 else 0.0
            bars.append((os.path.basename(csv_path), percent))

        bars = bars[:15]  

        x_positions = list(range(len(bars)))
        bar_width = 0.05 if len(bars) == 1 else 0.3  

        fig = go.Figure(data=[
            go.Bar(
                x=x_positions,
                y=[val for _, val in bars],
                text=[f"{val:.0f}%" for _, val in bars],
                hovertext=[name for name, _ in bars],
                
                textposition='outside',
                cliponaxis=False,

                width=[bar_width] * len(bars))])

        fig.update_layout(
            title="Detection Rate by File",
            xaxis=dict(
                title="CSV File",
                tickmode='array',
                tickvals=x_positions,
                ticktext=[name for name, _ in bars],
                type='category',
                showticklabels=True,
                tickangle=0,
                automargin=True),
            yaxis=dict(title="Detection Rate (%)",range=[0, 100],tick0=0,dtick=10),
            margin=dict(l=40, r=20, t=40, b=80),
            plot_bgcolor='rgba(240,240,240,0.95)',
            bargap=0.2)

        try:
            html = fig.to_html(include_plotlyjs='cdn')
            self.graph_view.setHtml(html)
        except Exception as e:
            print(f"Error displaying graph: {e}")
            self.graph_view.setHtml("<h3>Failed to render graph.</h3>")
            
    def show_about_dialog(self):
        QMessageBox.information(self, "About Threshold Tuner", "Version 1.0")

    def compute_detection_stats(self, file_path, threshold):
        detection_count = 0
        img_count = 0
        try:
            with open(file_path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                if reader.fieldnames:
                    reader.fieldnames = [h.strip().lstrip('\ufeff') for h in reader.fieldnames]
                for row in reader:
                    row = {k.strip(): (v.strip() if v else "") for k, v in row.items()}
                    selected_header = self.header_dropdown.currentText()
                    prob_str = row.get(selected_header, "")

                    img_str = row.get("Img Index", "")
                    if prob_str and img_str:
                        try:
                            prob = float(prob_str)
                            img_count += 1
                            if prob >= threshold:
                                detection_count += 1
                        except ValueError:
                            continue
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
        return detection_count, img_count

    def load_csv_headers(self, file_path):
        try:
            with open(file_path, newline='', encoding='utf-8') as f:
                reader = csv.reader(f)
                headers = next(reader, [])
                self.header_dropdown.clear()
                self.header_dropdown.addItems(headers)
        except Exception as e:
            print(f"Failed to load headers: {e}")
            self.header_dropdown.clear()

    def increment_slider(self):
        value = self.slider.value()
        if value < self.slider.maximum():
            self.slider.setValue(value + 1)

    def decrement_slider(self):
        value = self.slider.value()
        if value > self.slider.minimum():
            self.slider.setValue(value - 1)


    def generate_report(self):
        file_path = self.path_label.text()
        threshold = round(self.slider.value() / 100.0, 2)
        csv_files = self.csv_files

        if not csv_files:
            QMessageBox.warning(self, "No CSVs Found", "No valid CSV files found.")
            return

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        selected_header = self.header_dropdown.currentText().replace(" ", "_")
        selected_input = os.path.basename(file_path).replace(" ", "_").replace(".csv", "").replace(".txt", "")
        report_name = f"summaryReport__{selected_input}__{selected_header}__{threshold:.2f}__{timestamp}.csv"

        report_path = os.path.join(os.path.dirname(file_path), report_name)

        try:
            with open(report_path, "w", newline='', encoding='utf-8') as wf:
                writer = csv.writer(wf)
                writer.writerow(["File Name", "Threshold", "Detections Above Threshold", "Detection Rate (%)"])

                for csv_path in csv_files:
                    detection_count, img_count = self.compute_detection_stats(csv_path, threshold)
                    detection_rate = round((detection_count / img_count) * 100, 2) if img_count > 0 else 0.0
                    writer.writerow([os.path.basename(csv_path), f"{threshold:.2f}", detection_count, detection_rate])

            QMessageBox.information(self, "Report Saved", f"Report saved as:\n{report_name}")

        except PermissionError:
            QMessageBox.warning(self, "File Locked", "Cannot write to report file. Please close it if it's open.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error generating report:\n{e}")


    def detection_rate(self):
        file_path = self.path_label.text()
        threshold = self.slider.value() / 100.0
        detection_count = 0
        img_count = 0

        if not file_path.endswith(".csv"):
            print("Selected file is not a CSV.")
            return

        try:
            with open(file_path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)

                if reader.fieldnames:
                    reader.fieldnames = [h.strip().lstrip('\ufeff') for h in reader.fieldnames]

                for row in reader:

                    row = {k.strip(): (v.strip() if v else "") for k, v in row.items()}
                    print("CLEANED ROW:", row)  # Debug print

                    prob_str = row.get("Detection Probability", "")
                    img_str = row.get("Img Index", "")

                    if prob_str and img_str:
                        try:
                            prob = int(prob_str)
                            img_count += 1
                            if prob >= threshold:
                                detection_count += 1
                        except ValueError:
                            print("Skipping row due to invalid float:", row)
                            continue
                    else:
                        print("Skipping row due to missing values:", row)

            if img_count > 0:
                ratio = detection_count / img_count
                print(f"Threshold: {threshold:.2f}")
                print(f"Detection count above threshold: {detection_count}")
                print(f"Total image count: {img_count}")
                print(f"Detection Rate = {ratio:.2f}")
            else:
                print("No valid image entries found.")

        except Exception as e:
            print(f"Error reading CSV: {e}")
            
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CSVSelector()
    sys.exit(app.exec())
